﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MESForm
{
    public partial class PopUpSaleCost : MESForm.BaseForms.frmPopup
    {
        public PopUpSaleCost()
        {
            InitializeComponent();
        }
    }
}

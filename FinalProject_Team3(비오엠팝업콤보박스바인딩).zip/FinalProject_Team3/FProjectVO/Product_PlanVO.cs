﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FProjectVO
{
    public class Product_PlanVO
    {
       public int Process_Code { get; set; }
       public int Facility_Code { get; set; }
       public int ITEM_Code { get; set; }
       public DateTime PP_Fromdate { get; set; }
       public int PP_QTY { get; set; }
       



    }
}

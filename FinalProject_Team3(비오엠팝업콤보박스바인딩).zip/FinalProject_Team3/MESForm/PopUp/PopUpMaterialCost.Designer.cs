﻿namespace MESForm
{
    partial class PopUpMaterialCost
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.pnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.Size = new System.Drawing.Size(544, 40);
            // 
            // label1
            // 
            this.label1.Text = "자재단가";
            // 
            // btnCancel
            // 
            this.btnCancel.FlatAppearance.BorderColor = System.Drawing.SystemColors.GrayText;
            this.btnCancel.Location = new System.Drawing.Point(275, 348);
            // 
            // btnSave
            // 
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnSave.Location = new System.Drawing.Point(199, 348);
            // 
            // pnl
            // 
            this.pnl.Controls.Add(this.dateTimePicker1);
            this.pnl.Controls.Add(this.comboBox2);
            this.pnl.Controls.Add(this.comboBox1);
            this.pnl.Controls.Add(this.comboBox5);
            this.pnl.Controls.Add(this.textBox1);
            this.pnl.Controls.Add(this.label2);
            this.pnl.Controls.Add(this.label39);
            this.pnl.Controls.Add(this.textBox27);
            this.pnl.Controls.Add(this.label41);
            this.pnl.Controls.Add(this.label42);
            this.pnl.Controls.Add(this.textBox28);
            this.pnl.Controls.Add(this.label45);
            this.pnl.Controls.Add(this.comboBox16);
            this.pnl.Controls.Add(this.label46);
            this.pnl.Controls.Add(this.comboBox17);
            this.pnl.Controls.Add(this.label47);
            this.pnl.Controls.Add(this.label48);
            this.pnl.Controls.Add(this.comboBox18);
            this.pnl.Controls.Add(this.label50);
            this.pnl.Controls.Add(this.comboBox19);
            this.pnl.Controls.Add(this.label54);
            this.pnl.Controls.Add(this.label55);
            this.pnl.Size = new System.Drawing.Size(520, 296);
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.Location = new System.Drawing.Point(504, 0);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.dateTimePicker1.Location = new System.Drawing.Point(367, 68);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(138, 22);
            this.dateTimePicker1.TabIndex = 208;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(367, 6);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(138, 22);
            this.comboBox2.TabIndex = 207;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(113, 7);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(138, 22);
            this.comboBox1.TabIndex = 206;
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(367, 99);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(138, 22);
            this.comboBox5.TabIndex = 205;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.textBox1.Location = new System.Drawing.Point(107, 171);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(398, 120);
            this.textBox1.TabIndex = 204;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(20, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 14);
            this.label2.TabIndex = 203;
            this.label2.Text = "비고";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(275, 135);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(43, 14);
            this.label39.TabIndex = 202;
            this.label39.Text = "수정일";
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.textBox27.Location = new System.Drawing.Point(367, 130);
            this.textBox27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(138, 22);
            this.textBox27.TabIndex = 201;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(275, 105);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(55, 14);
            this.label41.TabIndex = 200;
            this.label41.Text = "사용유무";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(16, 135);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(43, 14);
            this.label42.TabIndex = 199;
            this.label42.Text = "수정자";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.textBox28.Location = new System.Drawing.Point(113, 132);
            this.textBox28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(138, 22);
            this.textBox28.TabIndex = 198;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label45.Location = new System.Drawing.Point(275, 74);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 14);
            this.label45.TabIndex = 197;
            this.label45.Text = "시작일";
            // 
            // comboBox16
            // 
            this.comboBox16.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Location = new System.Drawing.Point(113, 101);
            this.comboBox16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(138, 22);
            this.comboBox16.TabIndex = 196;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(20, 105);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(43, 14);
            this.label46.TabIndex = 195;
            this.label46.Text = "종료일";
            // 
            // comboBox17
            // 
            this.comboBox17.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(113, 71);
            this.comboBox17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(138, 22);
            this.comboBox17.TabIndex = 194;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label47.Location = new System.Drawing.Point(275, 43);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(55, 14);
            this.label47.TabIndex = 193;
            this.label47.Text = "현재단가";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label48.Location = new System.Drawing.Point(19, 74);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(55, 14);
            this.label48.TabIndex = 192;
            this.label48.Text = "이전단가";
            // 
            // comboBox18
            // 
            this.comboBox18.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Location = new System.Drawing.Point(367, 37);
            this.comboBox18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(138, 22);
            this.comboBox18.TabIndex = 191;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label50.Location = new System.Drawing.Point(20, 41);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(49, 14);
            this.label50.TabIndex = 190;
            this.label50.Text = "Market";
            // 
            // comboBox19
            // 
            this.comboBox19.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Location = new System.Drawing.Point(113, 40);
            this.comboBox19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(138, 22);
            this.comboBox19.TabIndex = 189;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label54.Location = new System.Drawing.Point(275, 9);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(31, 14);
            this.label54.TabIndex = 188;
            this.label54.Text = "품목";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("나눔스퀘어OTF", 9.749999F);
            this.label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label55.Location = new System.Drawing.Point(20, 9);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(31, 14);
            this.label55.TabIndex = 187;
            this.label55.Text = "업체";
            // 
            // PopUpMaterialCost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.ClientSize = new System.Drawing.Size(544, 396);
            this.Name = "PopUpMaterialCost";
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnl.ResumeLayout(false);
            this.pnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TextBox textBox1;
        protected System.Windows.Forms.Label label2;
        protected System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox27;
        protected System.Windows.Forms.Label label41;
        protected System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox28;
        protected System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox comboBox16;
        protected System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox comboBox17;
        protected System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
    }
}

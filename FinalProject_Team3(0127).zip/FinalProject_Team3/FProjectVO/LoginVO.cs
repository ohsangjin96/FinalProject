﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FProjectVO
{
    public class LoginVO
    {
        public string User_ID { get; set; }
        public string User_Pwd { get; set; }
        public string User_Name { get; set; }
        public string User_Email { get; set; }
        public string User_Dept { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FProjectVO
{
    public class MtpVO
    {
        public int Mtp_ID { get; set; }
        public string ITEM_Code { get; set; }
        public string Mtp_Category { get; set; }
        public DateTime Mtp_Date { get; set; }




        public string ITEM_Type { get; set; }
        public string ITEM_Name { get; set; }
        public string Plan_ID { get; set; }
    }
}

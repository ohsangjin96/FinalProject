﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FProjectVO
{
    public class CompanyVO
    {
        public long RowNo { get; set; }
        public string Com_Code { get; set; }
        public string Com_Name { get; set; }
        public string Com_Type { get; set; }
        public string Com_CEO { get; set; }
        public string Com_CNum { get; set; }
        public string Com_Category { get; set; }
        public string Com_Conditions { get; set; }
        public string Com_Charge { get; set; }
        public string Com_Email { get; set; }
        public string Com_StartDate { get; set; }
        public string Com_EndDate { get; set; }
        public string Com_Phone { get; set; }
        public string Com_Fax { get; set; }
        public string Com_Warehouse { get; set; }
        public string Com_Use { get; set; }
        public string Com_Amender { get; set; }
        public string Com_ModdifyDate { get; set; }
        public string Com_Info { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MESForm
{
    public partial class PopUpCreateGroup : MESForm.BaseForms.frmPopup
    {
        public PopUpCreateGroup()
        {
            InitializeComponent();
        }
    }
}
